﻿# Social_club
This is a website for The Club. It is a social Club for adults looking to make friends, exchange music, books, attend events and/or be involved in the commuinity. 
The site is mobile first. Meaning all of the media queries progress with the increased screen size. Media queries are used to display navbar to block, stack photos in using grid, 
to flex the sections of the page hide calendar icon and bar icon (dark purple) etc. I used CSS to style the navbar, adding hover features. Using grid to orgainize the page and photos. Javascript is being utlized in "sign-up"form. You click out side the form and it will close. 

